# AWS Connector

This tool provides a AWS CLI connector where you can switch roles to the account you want access to. 
